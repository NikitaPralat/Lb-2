﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task4
{
    class A
    {
        public A()
        {
            Console.WriteLine("Создан новый экземпляр");
        }
    }
}
