﻿using System;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            A newA = MyClass<A>.FacrotyMethod();
        }
        
    }
}
